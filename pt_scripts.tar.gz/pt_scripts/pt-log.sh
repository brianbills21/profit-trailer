tail -f /home/bbills/ProfitTrailer/ProfitTrailer.out
