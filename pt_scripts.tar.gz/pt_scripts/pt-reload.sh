kill -HUP `pidof java`
