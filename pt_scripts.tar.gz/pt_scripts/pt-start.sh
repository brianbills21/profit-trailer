cd /home/bbills/ProfitTrailer
nohup java -jar ProfitTrailer.jar -XX:+UseConcMarkSweepGC -Xmx256m -Xms256m >> ProfitTrailer.out 2>&1&
