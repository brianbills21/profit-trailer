test=$(ps -ef | grep "java" | sed '2d' | awk '{print $2}')
if [ "$test" != 0 ]
then
echo "running"" "$test
else
echo "not running"
fi
