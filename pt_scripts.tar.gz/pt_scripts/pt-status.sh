if [ `pidof java` != 0 ]
then
echo "Running"" "PID=""`pidof java`
else
echo "Not Running"
fi
