test=$(ps -ef | grep "UseConcMarkSweepGC" | sed '1d' | awk '{print $2}')
if [ "$test" != 0 ]
then
echo "running"" "$test
else
echo "not running"
fi
