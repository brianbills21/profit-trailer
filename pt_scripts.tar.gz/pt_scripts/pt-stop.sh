killall -9 java
